

export class employee{
    ID:string;
    Fname:string;
    Lname:string;
    Email:string;

}